package com.bytedance.compicatedcomponent.homework

import android.app.Activity
import android.content.Intent

import android.os.Bundle
import com.bytedance.compicatedcomponent.R
import android.os.Handler
import android.os.Looper
import android.os.Message
import com.bytedance.compicatedcomponent.handler.HomepageActivity

/**
 *  author : neo
 *  time   : 2021/10/30
 *  desc   :
 */
class ClockActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_clock)

    }


}
